/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pack1.subpackage;

/**
 *
 * @author ARUMUGASAMY
 */
public class third {
    public void display()
    {
        System.out.println("package 3");
    }        
    
}
